import { Component, OnInit} from '@angular/core';
import { ImageService } from '../services/image.service';
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  allImages: any[] = [];
  constructor(private imageservice: ImageService) {  
    for(let i=1;i<=5;i++){
      this.allImages.push('image ${i}');
    }
  }

  ngOnInit() {
    this.allImages = this.imageservice.getImages();
  }
}
