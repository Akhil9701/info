import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ImageService {
  allImages = [];
  constructor() { }

  getImages() {
    return this.allImages = IMAGES.slice(0);
  }
  getImage(id: number) {
    return IMAGES.slice(0).find(image => image.id == id)
  }
}

const IMAGES = [
  { "id": 1, "author": "View from the boat", "link": "assets/img/boat_01.jpeg", "url": "assets/img/boat_01.jpeg" },
  { "id": 2, "author": "Sailing the coast", "link": "assets/img/boat_02.jpeg", "url": "assets/img/boat_02.jpeg" },
  { "id": 3, "author": "The water was nice", "link": "assets/img/boat_03.jpeg", "url": "assets/img/boat_03.jpeg" },
  { "id": 4, "author": "Cool water cavern", "link": "assets/img/boat_04.jpeg", "url": "assets/img/boat_04.jpeg" },
  { "id": 5, "author": "Sunset at the docks", "link": "assets/img/boat_05.jpeg", "url": "assets/img/boat_05.jpeg" },
  { "id": 6, "author": "Camping Trip '17'", "link": "assets/img/camping_01.jpeg", "url": "assets/img/camping_01.jpeg" },
  { "id": 7, "author": "Kim and Jessie", "link": "assets/img/camping_02.jpeg", "url": "assets/img/camping_02.jpeg" },
  { "id": 8, "author": "View from the top", "link": "assets/img/camping_03.jpeg", "url": "assets/img/camping_03.jpeg" },
  { "id": 9, "author": "On the trail", "link": "assets/img/camping_04.jpg", "url": "assets/img/camping_04.jpg" },
  { "id": 10, "author": "Our camping spot", "link": "assets/img/camping_05.jpeg", "url": "assets/img/camping_05.jpeg" },
  { "id": 11, "author": "RV Life", "link": "assets/img/camping_06.jpg", "url": "assets/img/camping_06.jpg" },
  { "id": 12, "author": "Hiking trip 2017", "link": "assets/img/camping_07.jpeg","url": "assets/img/camping_07.jpeg" },
  { "id": 13, "author": "Big library", "link": "assets/img/library_01.jpeg", "url": "assets/img/library_01.jpeg" },
  { "id": 14, "author": "Stacks", "link": "assets/img/library_02.jpeg", "url": "assets/img/library_02.jpeg" },
  { "id": 15, "author": "Saturday afternoon", "link": "assets/img/library_03.jpeg", "url": "assets/img/library_03.jpeg" },
  { "id": 16, "author": "Local library", "link": "assets/img/library_04.jpeg", "url": "assets/img/library_04.jpeg" },
  { "id": 17, "author": "Nice library", "link": "assets/img/library_05.jpeg", "url": "assets/img/library_05.jpeg" }
]
